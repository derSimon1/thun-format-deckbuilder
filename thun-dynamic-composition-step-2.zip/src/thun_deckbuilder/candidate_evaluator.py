from __future__ import annotations

from typing import Callable

from thun_deckbuilder.candidate_score import CandidateScore, ScoreComponent
from thun_deckbuilder.card_contribution import CardContribution
from thun_deckbuilder.curve_scorer import CurveScorer
from thun_deckbuilder.deck_needs import DeckNeeds
from thun_deckbuilder.deck_profile import DeckProfile
from thun_deckbuilder.deck_state import DeckState
from thun_deckbuilder.knowledge_base import CardKnowledge
from thun_deckbuilder.role_need_scorer import RoleNeedScorer


ScoreFunction = Callable[[CardKnowledge], tuple[float, tuple[str, ...]]]


class CandidateEvaluator:
    """Combine static card quality with dynamic deck-state needs."""

    def __init__(
        self,
        role_scorer: RoleNeedScorer | None = None,
        curve_scorer: CurveScorer | None = None,
    ) -> None:
        self.role_scorer = role_scorer or RoleNeedScorer()
        self.curve_scorer = curve_scorer or CurveScorer()

    def evaluate(
        self,
        knowledge: CardKnowledge,
        contribution: CardContribution,
        state: DeckState,
        needs: DeckNeeds,
        profile: DeckProfile,
        *,
        score_card: ScoreFunction,
    ) -> CandidateScore:
        del state  # Reserved for copy and synergy scoring in the next package.
        base_score, reasons = score_card(knowledge)
        components: list[ScoreComponent] = [
            ScoreComponent(
                category="base_quality",
                value=base_score,
                reason="; ".join(reasons) if reasons else "Base strategy quality.",
            )
        ]
        components.extend(self.role_scorer.score(contribution, needs))
        curve_component = self.curve_scorer.score(contribution, needs, profile)
        if curve_component is not None:
            components.append(curve_component)
        return CandidateScore(card_name=contribution.card_name, components=tuple(components))
