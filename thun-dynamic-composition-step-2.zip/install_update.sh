#!/usr/bin/env bash
set -euo pipefail

PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(pwd)"

if [[ ! -f "${PROJECT_DIR}/pyproject.toml" || ! -d "${PROJECT_DIR}/src/thun_deckbuilder" ]]; then
    echo "Error: run this script from the thun-format-deckbuilder project root."
    exit 1
fi

echo "Installing Dynamic Composition Engine step 2..."
cp -R "${PACKAGE_DIR}/src/." "${PROJECT_DIR}/src/"
cp -R "${PACKAGE_DIR}/tests/." "${PROJECT_DIR}/tests/"
mkdir -p "${PROJECT_DIR}/docs"
cp -R "${PACKAGE_DIR}/docs/." "${PROJECT_DIR}/docs/"
chmod +x "${PROJECT_DIR}"/scripts/*.sh 2>/dev/null || true
python -m pip install -e .
./scripts/run_tests.sh

echo
echo "Update installed successfully. Expected test result: 76 passed."
