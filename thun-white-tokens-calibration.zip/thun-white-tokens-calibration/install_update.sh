#!/usr/bin/env bash
set -euo pipefail

PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(pwd)"

if [[ ! -f "$PROJECT_DIR/pyproject.toml" || ! -d "$PROJECT_DIR/src/thun_deckbuilder" ]]; then
  echo "Fehler: Bitte dieses Skript im Hauptordner des thun-format-deckbuilder-Repositories ausführen." >&2
  exit 1
fi

cp "$PACKAGE_DIR/src/thun_deckbuilder/token_scoring.py" "$PROJECT_DIR/src/thun_deckbuilder/token_scoring.py"
cp "$PACKAGE_DIR/src/thun_deckbuilder/token_generator.py" "$PROJECT_DIR/src/thun_deckbuilder/token_generator.py"
cp "$PACKAGE_DIR/tests/test_white_tokens_calibration.py" "$PROJECT_DIR/tests/test_white_tokens_calibration.py"
mkdir -p "$PROJECT_DIR/docs"
cp "$PACKAGE_DIR/docs/WHITE_TOKENS_CALIBRATION.md" "$PROJECT_DIR/docs/WHITE_TOKENS_CALIBRATION.md"
cp "$PACKAGE_DIR/CHANGELOG_WHITE_TOKENS_CALIBRATION.md" "$PROJECT_DIR/CHANGELOG_WHITE_TOKENS_CALIBRATION.md"

python -m pip install -e ".[dev]"
python -m pytest -q

echo
printf '%s\n' "White-Tokens-Kalibrierung erfolgreich installiert."
