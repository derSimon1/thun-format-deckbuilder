from __future__ import annotations

from dataclasses import dataclass

from thun_deckbuilder.deck_profile import DeckProfile
from thun_deckbuilder.deck_state import DeckState


@dataclass(frozen=True)
class RoleQuality:
    role: str
    current: float
    minimum: int
    target: int
    score: float

    @property
    def minimum_met(self) -> bool:
        return self.current >= self.minimum

    @property
    def target_met(self) -> bool:
        return self.current >= self.target


@dataclass(frozen=True)
class CurveQuality:
    label: str
    current: int
    target: int
    score: float

    @property
    def target_met(self) -> bool:
        return self.current >= self.target


@dataclass(frozen=True)
class DeckQualityReport:
    profile_name: str
    role_quality: tuple[RoleQuality, ...]
    curve_quality: tuple[CurveQuality, ...]
    role_score: float
    curve_score: float
    overall_score: int

    @property
    def minimums_met(self) -> bool:
        return all(item.minimum_met for item in self.role_quality)


class DeckQualityAnalyzer:
    """Measure profile fulfilment without changing card selection.

    Role targets contribute 70 percent and curve targets 30 percent. Scores are
    capped at 100, so exceeding a target does not hide a weakness elsewhere.
    """

    ROLE_WEIGHT = 0.70
    CURVE_WEIGHT = 0.30

    def analyze(self, state: DeckState, profile: DeckProfile) -> DeckQualityReport:
        roles = tuple(self._role_quality(state, target) for target in profile.role_targets)
        curves = self._curve_quality(state, profile)

        role_score = self._average(tuple(item.score for item in roles), default=100.0)
        curve_score = self._average(tuple(item.score for item in curves), default=100.0)
        overall = round(
            role_score * self.ROLE_WEIGHT + curve_score * self.CURVE_WEIGHT
        )
        return DeckQualityReport(
            profile_name=profile.name,
            role_quality=roles,
            curve_quality=curves,
            role_score=role_score,
            curve_score=curve_score,
            overall_score=max(0, min(100, overall)),
        )

    @staticmethod
    def _role_quality(state: DeckState, target) -> RoleQuality:
        current = state.role_count(target.role)
        score = 100.0 if target.target == 0 else min(100.0, current / target.target * 100.0)
        return RoleQuality(
            role=str(target.role),
            current=current,
            minimum=target.minimum,
            target=target.target,
            score=score,
        )

    @staticmethod
    def _curve_quality(state: DeckState, profile: DeckProfile) -> tuple[CurveQuality, ...]:
        result: list[CurveQuality] = []
        lower = 0.0
        for target in profile.curve_targets:
            current = state.curve_count(target.maximum_mana_value, lower)
            score = 100.0 if target.target == 0 else min(100.0, current / target.target * 100.0)
            result.append(
                CurveQuality(
                    label=f"{lower:g}-{target.maximum_mana_value:g}",
                    current=current,
                    target=target.target,
                    score=score,
                )
            )
            lower = target.maximum_mana_value
        return tuple(result)

    @staticmethod
    def _average(values: tuple[float, ...], *, default: float) -> float:
        return sum(values) / len(values) if values else default
