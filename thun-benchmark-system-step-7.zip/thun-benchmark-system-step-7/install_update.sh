#!/usr/bin/env bash
set -euo pipefail
PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(pwd)"
if [[ ! -f "$PROJECT_DIR/pyproject.toml" || ! -d "$PROJECT_DIR/src/thun_deckbuilder" ]]; then
  echo "Bitte dieses Skript im Hauptordner des thun-format-deckbuilder Repositorys starten."
  exit 1
fi
cp -R "$PACKAGE_DIR/src/." "$PROJECT_DIR/src/"
cp -R "$PACKAGE_DIR/tests/." "$PROJECT_DIR/tests/"
cp -R "$PACKAGE_DIR/docs/." "$PROJECT_DIR/docs/"
cp "$PACKAGE_DIR/CHANGELOG_STEP_7.md" "$PROJECT_DIR/"
cp "$PACKAGE_DIR/pyproject.toml" "$PROJECT_DIR/"
python -m pip install -e '.[dev]'
python -m pytest -q
