"""Packaged benchmark definitions."""
