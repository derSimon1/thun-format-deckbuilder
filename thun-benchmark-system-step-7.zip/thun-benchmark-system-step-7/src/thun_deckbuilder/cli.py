from __future__ import annotations

import argparse

from thun_deckbuilder.card_database import CardDatabase
from thun_deckbuilder.deck_builder import generate_deck
from thun_deckbuilder.prototype import format_deck
from thun_deckbuilder.benchmark_engine import BenchmarkEngine
from thun_deckbuilder.benchmark_loader import BenchmarkLoader
from thun_deckbuilder.benchmark_report import format_benchmark_report


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Magic Club Thun deckbuilder")
    subparsers = parser.add_subparsers(dest="command", required=True)

    deck = subparsers.add_parser("build", help="Generate a prototype deck")
    deck.add_argument("archetype", choices=("burn", "tokens"))
    deck.add_argument("--colors", nargs="+", required=True)
    deck.add_argument("--explain", action="store_true", help="Show every iterative selection decision")
    deck.add_argument("--benchmark", action="store_true", help="Compare the generated deck with its benchmark")

    benchmark = subparsers.add_parser("benchmark", help="Generate and benchmark a supported archetype")
    benchmark.add_argument("archetype", choices=("burn", "tokens"))
    benchmark.add_argument("--colors", nargs="+")

    legality = subparsers.add_parser("legal", help="Check one card")
    legality.add_argument("card_name")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    with CardDatabase() as database:
        if args.command == "legal":
            card = database.get_card_by_name(args.card_name)
            if card is None:
                print(f"Karte nicht gefunden: {args.card_name}")
                return 2
            legal = database.is_card_legal_by_name(args.card_name)
            print(f"{card['name']}: {'LEGAL' if legal else 'NICHT LEGAL'}")
            return 0 if legal else 1

        benchmark_mode = args.command == "benchmark" or getattr(args, "benchmark", False)
        default_colors = {"burn": ("R",), "tokens": ("W",)}
        colors = tuple(args.colors or default_colors[args.archetype])
        deck = generate_deck(
            database=database,
            archetype=args.archetype,
            colors=colors,
        )
        output = format_deck(
            deck,
            archetype=args.archetype,
            colors=colors,
            explain=getattr(args, "explain", False),
        )
        if benchmark_mode:
            key = {"burn": "mono_red_burn", "tokens": "white_tokens"}[args.archetype]
            definition = BenchmarkLoader().load(key)
            report = BenchmarkEngine().evaluate(deck, definition)
            output += "\n\n" + "\n".join(format_benchmark_report(report))
        print(output)
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
