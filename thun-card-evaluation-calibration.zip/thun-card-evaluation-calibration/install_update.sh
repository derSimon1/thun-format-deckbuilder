#!/usr/bin/env bash
set -euo pipefail

PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(pwd)"

if [[ ! -f "$PROJECT_DIR/pyproject.toml" || ! -d "$PROJECT_DIR/src/thun_deckbuilder" ]]; then
  echo "Fehler: Bitte dieses Skript im Hauptordner des thun-format-deckbuilder-Repositories ausführen." >&2
  exit 1
fi

cp "$PACKAGE_DIR/src/thun_deckbuilder/card_evaluation.py" "$PROJECT_DIR/src/thun_deckbuilder/card_evaluation.py"
cp "$PACKAGE_DIR/tests/test_card_evaluation_calibration.py" "$PROJECT_DIR/tests/test_card_evaluation_calibration.py"
mkdir -p "$PROJECT_DIR/docs"
cp "$PACKAGE_DIR/docs/CARD_EVALUATION_CALIBRATION.md" "$PROJECT_DIR/docs/CARD_EVALUATION_CALIBRATION.md"
cp "$PACKAGE_DIR/CHANGELOG_CARD_EVALUATION_CALIBRATION.md" "$PROJECT_DIR/CHANGELOG_CARD_EVALUATION_CALIBRATION.md"

python -m pip install -e ".[dev]"
python -m pytest -q

echo
printf '%s\n' "Card-Evaluation-Kalibrierung erfolgreich installiert."
