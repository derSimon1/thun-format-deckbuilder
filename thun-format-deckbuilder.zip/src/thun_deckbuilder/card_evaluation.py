from __future__ import annotations

from dataclasses import dataclass
import re

from thun_deckbuilder.card_analyzer import CardAnalysis


@dataclass(frozen=True)
class EvaluationComponent:
    category: str
    value: float
    reason: str


@dataclass(frozen=True)
class CardEvaluation:
    components: tuple[EvaluationComponent, ...]

    @property
    def total(self) -> float:
        return sum(component.value for component in self.components)

    @property
    def reasons(self) -> tuple[str, ...]:
        return tuple(component.reason for component in self.components)


class CardEvaluationEngine:
    """Estimate intrinsic card quality using conservative Oracle-text heuristics.

    The engine intentionally evaluates only qualities that can be inferred with
    reasonable confidence. Archetype fit, deck needs, curve and synergy remain
    separate dynamic concerns handled by CandidateEvaluator.
    """

    def evaluate(self, analysis: CardAnalysis) -> CardEvaluation:
        if analysis.is_land:
            return CardEvaluation(())

        components: list[EvaluationComponent] = []
        text = analysis.oracle_text.lower()
        mv = max(analysis.mana_value, 0.0)

        components.append(self._mana_efficiency(analysis))

        if analysis.is_instant:
            components.append(EvaluationComponent("flexibility", 1.5, "Instant-speed flexibility."))
        elif "flash" in text:
            components.append(EvaluationComponent("flexibility", 1.0, "Flash enables reactive play."))

        if self._draws_cards(text):
            value = 3.0 if self._draw_count(text) >= 2 else 1.5
            components.append(EvaluationComponent("card_advantage", value, "Provides card advantage or selection."))

        if "create" in text and "token" in text:
            components.append(EvaluationComponent("board_impact", 1.5, "Adds multiple bodies or material to the battlefield."))

        if any(term in text for term in ("destroy target", "exile target", "deals ")):
            value = 2.0 if analysis.is_instant or mv <= 2 else 1.0
            components.append(EvaluationComponent("interaction", value, "Provides direct interaction."))

        if any(term in text for term in ("enters the battlefield", "when this creature enters")):
            components.append(EvaluationComponent("immediate_value", 1.0, "Generates value on entering the battlefield."))

        if any(term in text for term in ("haste", "hexproof", "ward", "indestructible")):
            components.append(EvaluationComponent("resilience_tempo", 1.0, "Has a relevant tempo or resilience keyword."))

        if analysis.is_creature and analysis.power is not None and analysis.toughness is not None and mv > 0:
            rate = (analysis.power + analysis.toughness) / (2 * mv)
            if rate >= 1.25:
                components.append(EvaluationComponent("creature_rate", 1.5, "Above-rate power and toughness for its mana value."))
            elif rate < 0.65 and not self._draws_cards(text) and "create" not in text:
                components.append(EvaluationComponent("creature_rate", -1.0, "Below-rate body without clear immediate compensation."))

        if mv >= 5 and not any(component.category in {"card_advantage", "board_impact", "interaction", "immediate_value"} for component in components):
            components.append(EvaluationComponent("expensive_low_impact", -2.0, "High mana value without a clear immediate impact."))

        return CardEvaluation(tuple(component for component in components if component.value != 0))

    @staticmethod
    def _mana_efficiency(analysis: CardAnalysis) -> EvaluationComponent:
        mv = analysis.mana_value
        if mv <= 1:
            return EvaluationComponent("mana_efficiency", 2.0, "Very low mana value.")
        if mv <= 2:
            return EvaluationComponent("mana_efficiency", 1.5, "Efficient mana value.")
        if mv <= 3:
            return EvaluationComponent("mana_efficiency", 0.5, "Moderate mana value.")
        if mv >= 6:
            return EvaluationComponent("mana_efficiency", -1.5, "Very high mana value requires substantial impact.")
        if mv >= 5:
            return EvaluationComponent("mana_efficiency", -0.5, "High mana value.")
        return EvaluationComponent("mana_efficiency", 0.0, "Neutral mana efficiency.")

    @staticmethod
    def _draws_cards(text: str) -> bool:
        return bool(re.search(r"draw (?:a|one|two|three|\d+) cards?", text))

    @staticmethod
    def _draw_count(text: str) -> int:
        match = re.search(r"draw (a|one|two|three|\d+) cards?", text)
        if not match:
            return 0
        token = match.group(1)
        return {"a": 1, "one": 1, "two": 2, "three": 3}.get(token, int(token) if token.isdigit() else 1)
