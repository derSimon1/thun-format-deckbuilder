#!/usr/bin/env bash
set -euo pipefail

ROOT="$(pwd)"
PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ ! -f "$ROOT/pyproject.toml" || ! -d "$ROOT/src/thun_deckbuilder" ]]; then
  echo "Error: run this script from the thun-format-deckbuilder repository root." >&2
  exit 1
fi

echo "Installing Card Evaluation Engine package..."
cp -f "$PACKAGE_DIR"/src/thun_deckbuilder/*.py "$ROOT/src/thun_deckbuilder/"
cp -f "$PACKAGE_DIR"/tests/*.py "$ROOT/tests/"
mkdir -p "$ROOT/docs"
cp -f "$PACKAGE_DIR"/docs/*.md "$ROOT/docs/"
cp -f "$PACKAGE_DIR/CHANGELOG_STEP_6.md" "$ROOT/"

python -m pip install -e '.[dev]'
python -m pytest -q

echo "Installation complete. Expected result: 102 passed."
echo "Run an explainable build to inspect intrinsic_quality components."
