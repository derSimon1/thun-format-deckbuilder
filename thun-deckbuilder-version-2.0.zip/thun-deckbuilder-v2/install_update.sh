#!/usr/bin/env bash
set -euo pipefail

PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(pwd)"

if [[ ! -f "$PROJECT_DIR/pyproject.toml" || ! -d "$PROJECT_DIR/src/thun_deckbuilder" ]]; then
  echo "Error: run this script from the thun-format-deckbuilder repository root." >&2
  exit 1
fi

echo "Installing Thun Deckbuilder Version 2.0 into: $PROJECT_DIR"
cp -R "$PACKAGE_DIR/src/." "$PROJECT_DIR/src/"
cp -R "$PACKAGE_DIR/tests/." "$PROJECT_DIR/tests/"
mkdir -p "$PROJECT_DIR/docs"
cp -R "$PACKAGE_DIR/docs/." "$PROJECT_DIR/docs/"
cp "$PACKAGE_DIR/CHANGELOG_VERSION_2_0.md" "$PROJECT_DIR/"

export PYTHONPATH="$PROJECT_DIR/src${PYTHONPATH:+:$PYTHONPATH}"
python -m pytest -q

echo "Version 2.0 installed successfully. Expected result: 110 passed."
